"""FastMCP utility modules."""
