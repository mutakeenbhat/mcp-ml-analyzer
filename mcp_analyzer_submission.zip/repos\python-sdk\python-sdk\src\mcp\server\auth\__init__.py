"""
MCP OAuth server authorization components.
"""
