import sys

from .server import main

sys.exit(main())  # type: ignore[call-arg]
